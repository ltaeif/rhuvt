-- phpMyAdmin SQL Dump
-- version 4.0.10.10
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Ven 03 Juillet 2015 à 07:36
-- Version du serveur: 5.1.50-community
-- Version de PHP: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `grh`
--

-- --------------------------------------------------------

--
-- Structure de la table `cvcentresinteret`
--

CREATE TABLE IF NOT EXISTS `cvcentresinteret` (
  `idcvcentresinteret` bigint(20) NOT NULL AUTO_INCREMENT,
  `idcandidatcv` bigint(20) NOT NULL,
  `label` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`idcvcentresinteret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `cvdivers`
--

CREATE TABLE IF NOT EXISTS `cvdivers` (
  `idcvdivers` bigint(20) NOT NULL AUTO_INCREMENT,
  `idcandidatcv` bigint(20) NOT NULL,
  `idcvtypedivers` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `diverslabel` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `niveaux` varchar(55) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idcvdivers`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `cvformations`
--

CREATE TABLE IF NOT EXISTS `cvformations` (
  `idcvformations` int(11) NOT NULL AUTO_INCREMENT,
  `idcandidatcv` bigint(20) NOT NULL,
  `CPAYS` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `idlangues` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `dateoptention` date DEFAULT NULL,
  `titrediplome` text COLLATE utf8_unicode_ci,
  `diplomant` tinyint(4) DEFAULT NULL,
  `diplomefile` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `onrganisme` text COLLATE utf8_unicode_ci,
  `codecertif` text COLLATE utf8_unicode_ci,
  `score` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`idcvformations`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Contenu de la table `cvformations`
--

INSERT INTO `cvformations` (`idcvformations`, `idcandidatcv`, `CPAYS`, `idlangues`, `dateoptention`, `titrediplome`, `diplomant`, `diplomefile`, `description`, `onrganisme`, `codecertif`, `score`) VALUES
(3, 7, 'TN', 'fr', '0000-00-00', 'Bureautique ', 1, NULL, 'J''été un formateur en informatique et j''ai eu le faveur de passé gratuitement la certification des outils bureautique', 'ENDA', '01258', '19.00'),
(4, 7, 'TN', 'fr', '0000-00-00', 'Oracle', 1, NULL, 'cxwcxwcxw', 'université virtuelle de tunis', '01258', '10.00');

-- --------------------------------------------------------

--
-- Structure de la table `cvlangueinformatique`
--

CREATE TABLE IF NOT EXISTS `cvlangueinformatique` (
  `idcvlangueinformatique` bigint(20) NOT NULL AUTO_INCREMENT,
  `idcandidatcv` bigint(20) NOT NULL,
  `label` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`idcvlangueinformatique`),
  KEY `fk_cvcentresinteret_candidatcv1` (`idcandidatcv`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Contenu de la table `cvlangueinformatique`
--

INSERT INTO `cvlangueinformatique` (`idcvlangueinformatique`, `idcandidatcv`, `label`, `description`) VALUES
(1, 7, 'PHP5, HTML, JAVASCRIPT, C++', 'metrise des langage de dev');

-- --------------------------------------------------------

--
-- Structure de la table `cvloisirs`
--

CREATE TABLE IF NOT EXISTS `cvloisirs` (
  `idcvloisirs` bigint(20) NOT NULL AUTO_INCREMENT,
  `idcandidatcv` bigint(20) NOT NULL,
  `idlangues` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `natureloisir` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `ordre` int(11) DEFAULT NULL,
  PRIMARY KEY (`idcvloisirs`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Contenu de la table `cvloisirs`
--

INSERT INTO `cvloisirs` (`idcvloisirs`, `idcandidatcv`, `idlangues`, `natureloisir`, `description`, `ordre`) VALUES
(1, 7, 'fr', 'Sport, Natation, Informatique, Internet', 'je pratique de sport', 1);

-- --------------------------------------------------------

--
-- Structure de la table `cvparcoursetud`
--

CREATE TABLE IF NOT EXISTS `cvparcoursetud` (
  `idcvparcoursetud` bigint(20) NOT NULL AUTO_INCREMENT,
  `idcandidatcv` bigint(20) NOT NULL,
  `CPAYS` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `idlangues` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `idtypesdiplome` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `idbacplus` varchar(35) COLLATE utf8_unicode_ci DEFAULT NULL,
  `diplometitre` text COLLATE utf8_unicode_ci,
  `anneeobtention` year(4) DEFAULT NULL,
  `session` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `moyenne` decimal(4,2) DEFAULT NULL,
  `relevenote` text COLLATE utf8_unicode_ci,
  `diplomefile` text COLLATE utf8_unicode_ci,
  `universite` text COLLATE utf8_unicode_ci,
  `credit` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idcvparcoursetud`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `cvparcourspro`
--

CREATE TABLE IF NOT EXISTS `cvparcourspro` (
  `idcvparcourspro` bigint(20) NOT NULL AUTO_INCREMENT,
  `idcandidatcv` bigint(20) NOT NULL,
  `CPAYS` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `idlangues` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `entreprise` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `daterecrutement` date DEFAULT NULL,
  `datedesuspension` date DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `lieu` text COLLATE utf8_unicode_ci,
  `poste` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`idcvparcourspro`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Contenu de la table `cvparcourspro`
--

INSERT INTO `cvparcourspro` (`idcvparcourspro`, `idcandidatcv`, `CPAYS`, `idlangues`, `entreprise`, `daterecrutement`, `datedesuspension`, `description`, `lieu`, `poste`) VALUES
(1, 1, 'TN', 'fr', 'INSEN', '2009-08-01', '2010-08-01', ' Network Engineer  ', 'Monastir', 'Network ');

-- --------------------------------------------------------

--
-- Structure de la table `cvtypedivers`
--

CREATE TABLE IF NOT EXISTS `cvtypedivers` (
  `idcvtypedivers` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`idcvtypedivers`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `cvtypesdiplome`
--

CREATE TABLE IF NOT EXISTS `cvtypesdiplome` (
  `idtypesdiplome` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`idtypesdiplome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `cvtypesdiplome`
--

INSERT INTO `cvtypesdiplome` (`idtypesdiplome`, `description`) VALUES
('Universitaire', 'Universitaire');

-- --------------------------------------------------------

--
-- Structure de la table `departement`
--

CREATE TABLE IF NOT EXISTS `departement` (
  `iddepartement` int(11) NOT NULL AUTO_INCREMENT,
  `root` int(11) NOT NULL,
  PRIMARY KEY (`iddepartement`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1021 ;

--
-- Contenu de la table `departement`
--

INSERT INTO `departement` (`iddepartement`, `root`) VALUES
(1, 0),
(2, 0),
(3, 1),
(4, 1),
(1000, 1000),
(1001, 1),
(1002, 1),
(1003, 1),
(1004, 1),
(1005, 1),
(1006, 1),
(1007, 1),
(1008, 1),
(1009, 1),
(1010, 1),
(1011, 1),
(1012, 1),
(1013, 1),
(1014, 1),
(1015, 1),
(1016, 1),
(1017, 1),
(1018, 1),
(1019, 1),
(1020, 1);

-- --------------------------------------------------------

--
-- Structure de la table `departement_lang`
--

CREATE TABLE IF NOT EXISTS `departement_lang` (
  `iddepartement_lang` int(11) NOT NULL AUTO_INCREMENT,
  `departement_iddepartement` int(11) NOT NULL,
  `intitule` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `abrev` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang_idlang` int(11) NOT NULL,
  PRIMARY KEY (`iddepartement_lang`),
  KEY `fk_departement_lang_departement1` (`departement_iddepartement`),
  KEY `fk_departement_lang_lang1` (`lang_idlang`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Contenu de la table `departement_lang`
--

INSERT INTO `departement_lang` (`iddepartement_lang`, `departement_iddepartement`, `intitule`, `abrev`, `lang_idlang`) VALUES
(1, 1, 'المصالح المشتركة', NULL, 1),
(2, 2, 'الشؤون الأكاديمية', NULL, 1),
(3, 3, 'الادارة الفرعية للشؤون المالية', NULL, 1),
(4, 4, 'الادارة الفرعية للموارد البشرية ', NULL, 1);

-- --------------------------------------------------------

--
-- Structure de la table `grade`
--

CREATE TABLE IF NOT EXISTS `grade` (
  `idgrade` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idgrade`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Contenu de la table `grade`
--

INSERT INTO `grade` (`idgrade`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(17),
(18);

-- --------------------------------------------------------

--
-- Structure de la table `grade_lang`
--

CREATE TABLE IF NOT EXISTS `grade_lang` (
  `idgrade_lang` int(11) NOT NULL AUTO_INCREMENT,
  `grade_idgrade` int(11) NOT NULL,
  `intitule` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang_idlang` int(11) NOT NULL,
  PRIMARY KEY (`idgrade_lang`),
  KEY `fk_grade_lang_grade2` (`grade_idgrade`),
  KEY `fk_grade_lang_lang2` (`lang_idlang`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=68 ;

--
-- Contenu de la table `grade_lang`
--

INSERT INTO `grade_lang` (`idgrade_lang`, `grade_idgrade`, `intitule`, `lang_idlang`) VALUES
(46, 1, 'مهندس رئيس', 1),
(47, 2, 'مهندس أول', 1),
(48, 3, 'متصرف مستشار', 1),
(49, 4, 'محلل', 1),
(50, 5, 'متصرف', 1),
(51, 6, 'تقني', 1),
(52, 7, 'واضع برامج', 1),
(53, 8, 'موثق مساعد', 1),
(54, 9, 'ملحق إدارة', 1),
(55, 10, 'موثق مساعد', 1),
(61, 11, 'كاتب راقن', 1),
(62, 12, 'كاتب تصرف', 1),
(63, 13, 'مستكتب إدارة', 1),
(64, 14, 'عامل صنف 1', 1),
(65, 15, 'عامل صنف 2', 1),
(66, 16, 'عامل صنف 3', 1),
(67, 17, 'عامل صنف 4', 1);

-- --------------------------------------------------------

--
-- Structure de la table `lang`
--

CREATE TABLE IF NOT EXISTS `lang` (
  `idlang` int(11) NOT NULL AUTO_INCREMENT,
  `iso_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `intitule` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(4) DEFAULT '1',
  `default` tinyint(4) DEFAULT '0',
  `deleted` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`idlang`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Contenu de la table `lang`
--

INSERT INTO `lang` (`idlang`, `iso_code`, `intitule`, `active`, `default`, `deleted`) VALUES
(1, 'ar', 'Arabe', 1, 1, 0),
(2, 'fr', 'Français', 1, 0, 0),
(3, 'en', 'Anglais', 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `params`
--

CREATE TABLE IF NOT EXISTS `params` (
  `idparams` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  PRIMARY KEY (`idparams`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `params`
--

INSERT INTO `params` (`idparams`, `type`, `id`) VALUES
('AUTSORTIE', 'HEURE_INTERVAL', 5),
('AUTSPECIAL', 'JOUR', 3),
('HSUP', 'HEURE_INTERVAL', 6),
('JCA', 'JOUR', 1),
('JCM', 'JOUR', 2),
('NUM', 'CHIFFRE', 7),
('RETARD', 'HEURE', 4);

-- --------------------------------------------------------

--
-- Structure de la table `params_details`
--

CREATE TABLE IF NOT EXISTS `params_details` (
  `idparams_details` int(11) NOT NULL AUTO_INCREMENT,
  `personnel_idpersonnel` int(11) NOT NULL,
  `params_idparams` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `date1` datetime DEFAULT NULL,
  `date2` datetime DEFAULT NULL,
  PRIMARY KEY (`idparams_details`),
  KEY `fk_params_details_params1` (`params_idparams`),
  KEY `fk_params_details_personnel1` (`personnel_idpersonnel`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=22 ;

--
-- Contenu de la table `params_details`
--

INSERT INTO `params_details` (`idparams_details`, `personnel_idpersonnel`, `params_idparams`, `date1`, `date2`) VALUES
(1, 1, 'JCA', '2012-06-01 00:00:00', '2012-06-08 07:05:00'),
(2, 1, 'JCM', '2012-06-06 00:00:00', '2012-06-06 00:00:00'),
(3, 1, 'RETARD', '2012-06-08 15:00:00', NULL),
(4, 1, 'AUTSORTIE', '2012-06-08 16:00:00', '2012-06-08 17:05:00'),
(5, 1, 'JCA', '2012-06-13 00:00:00', NULL),
(6, 1, 'JCA', '2012-06-08 00:00:00', '2012-06-09 00:00:00'),
(7, 1, 'JCA', '2012-06-09 00:00:00', '2012-06-20 00:00:00'),
(8, 1, 'HSUP', '2012-06-08 16:23:00', '2012-06-08 16:25:00'),
(10, 1, 'AUTSPECIAL', '2012-06-09 00:00:00', '2012-07-08 00:00:00'),
(11, 1, 'AUTSORTIE', '2012-06-09 09:57:00', '2012-06-09 10:50:00'),
(12, 1, 'JCA', '2012-06-09 00:00:00', '2012-06-14 00:00:00'),
(13, 1, 'JCA', '2012-06-09 00:00:00', '2012-06-14 00:00:00'),
(14, 1, 'RETARD', '2012-06-11 09:10:00', NULL),
(15, 1, 'RETARD', '2012-06-11 12:12:00', NULL),
(16, 1, 'RETARD', '2012-06-11 15:17:00', NULL),
(17, 1, 'RETARD', '2012-06-11 12:15:00', NULL),
(20, 1, 'HSUP', '2012-06-12 05:10:00', '2012-06-12 06:20:00'),
(21, 1, 'JCA', '2012-01-01 00:00:00', '2012-01-03 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `params_lang`
--

CREATE TABLE IF NOT EXISTS `params_lang` (
  `idparams_lang` int(11) NOT NULL AUTO_INCREMENT,
  `params_idparams` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `intitule` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang_idlang` int(11) NOT NULL,
  PRIMARY KEY (`idparams_lang`),
  KEY `fk_params_lang_lang1` (`lang_idlang`),
  KEY `fk_params_lang_params1` (`params_idparams`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Contenu de la table `params_lang`
--

INSERT INTO `params_lang` (`idparams_lang`, `params_idparams`, `intitule`, `lang_idlang`) VALUES
(1, 'JCA', 'أيام العطل السنوية', 1),
(2, 'JCM', 'أيام عطل المرض', 1),
(3, 'AUTSPECIAL', 'رخص استثنائية', 1),
(4, 'RETARD', 'وحدات التأخير', 1),
(5, 'AUTSORTIE', 'رخص الخروج', 1),
(6, 'HSUP', 'ساعات العمل الإضافي', 1),
(7, 'NUM', 'العدد المسند', 1);

-- --------------------------------------------------------

--
-- Structure de la table `personne`
--

CREATE TABLE IF NOT EXISTS `personne` (
  `idpersonne` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `forename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `login` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(4) DEFAULT '1',
  `deleted` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`idpersonne`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Contenu de la table `personne`
--

INSERT INTO `personne` (`idpersonne`, `name`, `forename`, `login`, `password`, `active`, `deleted`) VALUES
(1, 'Ltaief', 'Kortas', 'kortaskas@hotmail.fr', 'azerty', 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `personnel`
--

CREATE TABLE IF NOT EXISTS `personnel` (
  `idpersonnel` int(11) NOT NULL AUTO_INCREMENT,
  `grade_idgrade` int(11) DEFAULT NULL,
  `managerid` int(11) DEFAULT '0',
  `iddepartement` int(11) DEFAULT NULL,
  `cnrps` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cin` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `specialite` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tel` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `addresse` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codepostal` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Ville` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_upd` datetime DEFAULT NULL,
  `date_add` datetime DEFAULT NULL,
  `active` tinyint(4) DEFAULT '1',
  `position` int(11) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`idpersonnel`),
  KEY `fk_personnel_grade2` (`grade_idgrade`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=91 ;

--
-- Contenu de la table `personnel`
--

INSERT INTO `personnel` (`idpersonnel`, `grade_idgrade`, `managerid`, `iddepartement`, `cnrps`, `cin`, `email`, `specialite`, `tel`, `fax`, `addresse`, `codepostal`, `Ville`, `picture`, `date_upd`, `date_add`, `active`, `position`, `deleted`) VALUES
(1, 3, 74, 0, '8218547011', '82185470', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'patientPhotoId.jpg', NULL, NULL, 1, 0, 0),
(2, 3, 0, 0, '82171528', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 5, 0),
(3, 3, 0, 3, '79760470', '05556565', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 0),
(4, 3, 0, 0, '79757945', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 6, 0),
(5, 3, 0, 0, '77069429', '0548722', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 4, 0),
(6, 3, 0, 0, '86220872777777777777', '77777777', 'kortaskas@hotmail.fr', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 2, 0),
(72, 1, 0, 0, '5293704144', '44444444', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 7, 0),
(74, 2, 0, 3, '2303762528', '08473677', 'kortasabdellatif@gmail.com', NULL, NULL, NULL, 'Akouda', '4022', 'Sousse', 'patientPhotoId.jpg', NULL, NULL, 1, 3, 0),
(76, 3, 0, 2, NULL, '014785236', 'ammariimen@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1),
(77, 3, 0, 2, '666666', '55555', 'ammariimen2@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0),
(81, 4, 0, NULL, NULL, '1515', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0),
(82, 2, 0, 3, NULL, '54545454545444444444', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0),
(83, 4, 74, NULL, NULL, '84654165413513513212', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0),
(84, 2, 0, 3, NULL, '84654165413513513212', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0),
(85, 1, 74, 4, NULL, '66656444444444444444', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0),
(86, 1, 74, 4, NULL, '66656444444444444444', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0),
(87, 1, 74, 4, NULL, '22222222222222222222', 'kortasabdellatif3@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0),
(88, 1, 74, 4, NULL, '22222222222222222222', 'kortasabdellatif2@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0),
(89, 1, 84, 2, '65666666666666666666', '05641223', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0),
(90, 1, 0, 1, NULL, '22222222222222222222', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 0);

-- --------------------------------------------------------

--
-- Structure de la table `personnel_lang`
--

CREATE TABLE IF NOT EXISTS `personnel_lang` (
  `idpersonnel_lang` int(11) NOT NULL AUTO_INCREMENT,
  `personnel_idpersonnel` int(11) NOT NULL,
  `nom` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prenom` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang_idlang` int(11) NOT NULL,
  PRIMARY KEY (`idpersonnel_lang`),
  KEY `fk_personnel_lang_lang2` (`lang_idlang`),
  KEY `fk_personnel_lang_personnel2` (`personnel_idpersonnel`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=165 ;

--
-- Contenu de la table `personnel_lang`
--

INSERT INTO `personnel_lang` (`idpersonnel_lang`, `personnel_idpersonnel`, `nom`, `prenom`, `lang_idlang`) VALUES
(1, 1, 'بودوّارة', 'سلوى', 1),
(2, 2, 'الرّايس', 'أسماء', 1),
(3, 3, 'الهذيلي', 'حاتم', 1),
(4, 4, 'كوكا ', 'اسكندر', 1),
(5, 5, 'التليلي', 'الصّحبي', 1),
(6, 6, 'المحجوبي', 'أماني', 1),
(112, 72, 'الزموري', 'مالك', 1),
(113, 72, 'zammouri', 'Malek', 2),
(114, 72, NULL, NULL, 3),
(115, 1, 'BouDawwara', 'Salwa', 2),
(116, 1, NULL, NULL, 3),
(117, 74, 'قرطاس', 'عبداللطيف', 1),
(118, 74, 'Kortas', 'Abdellatif', 2),
(119, 74, 'Abdellatif', 'Kortas', 3),
(120, 3, NULL, NULL, 2),
(121, 3, NULL, NULL, 3),
(122, 76, 'Kortas222', 'qsdqsd', 1),
(123, 76, NULL, NULL, 2),
(124, 76, NULL, NULL, 3),
(125, 77, 'أببب ', 'بففرج', 1),
(126, 77, 'begregeee', 'abib', 2),
(127, 77, NULL, NULL, 3),
(128, 5, 'tlili', 'sahbi2', 2),
(129, 5, NULL, NULL, 3),
(142, 82, 'الز', 'بففرج', 1),
(143, 82, 'za', 'befr', 2),
(144, 82, NULL, NULL, 3),
(145, 83, 'Ab', 'bb', 1),
(146, 83, 'ab', 'aa', 2),
(147, 83, NULL, NULL, 3),
(148, 84, 'أب', 'بب ', 1),
(149, 84, 'Kortas', 'abib', 2),
(150, 84, NULL, NULL, 3),
(151, 87, 'أببب ', 'Abdellatif', 1),
(152, 87, NULL, 'Abdellatif', 2),
(153, 87, 'Kortas', NULL, 3),
(154, 88, 'أببب ', 'Abdellatif', 1),
(155, 88, NULL, 'Abdellatif', 2),
(156, 88, 'Kortas', NULL, 3),
(157, 89, 'أببب ', 'مالك', 1),
(158, 89, NULL, NULL, 2),
(159, 89, NULL, NULL, 3),
(160, 90, 'أببب ', 'مالك', 1),
(161, 90, NULL, NULL, 2),
(162, 90, NULL, NULL, 3),
(163, 6, NULL, NULL, 2),
(164, 6, NULL, NULL, 3);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `grade_lang`
--
ALTER TABLE `grade_lang`
  ADD CONSTRAINT `fk_grade_lang_grade2` FOREIGN KEY (`grade_idgrade`) REFERENCES `grade` (`idgrade`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_grade_lang_lang2` FOREIGN KEY (`lang_idlang`) REFERENCES `lang` (`idlang`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `params_details`
--
ALTER TABLE `params_details`
  ADD CONSTRAINT `fk_params_details_params1` FOREIGN KEY (`params_idparams`) REFERENCES `params` (`idparams`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_params_details_personnel1` FOREIGN KEY (`personnel_idpersonnel`) REFERENCES `personnel` (`idpersonnel`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `params_lang`
--
ALTER TABLE `params_lang`
  ADD CONSTRAINT `fk_params_lang_lang1` FOREIGN KEY (`lang_idlang`) REFERENCES `lang` (`idlang`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_params_lang_params1` FOREIGN KEY (`params_idparams`) REFERENCES `params` (`idparams`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `personnel`
--
ALTER TABLE `personnel`
  ADD CONSTRAINT `fk_personnel_grade2` FOREIGN KEY (`grade_idgrade`) REFERENCES `grade` (`idgrade`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `personnel_lang`
--
ALTER TABLE `personnel_lang`
  ADD CONSTRAINT `fk_personnel_lang_lang2` FOREIGN KEY (`lang_idlang`) REFERENCES `lang` (`idlang`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_personnel_lang_personnel2` FOREIGN KEY (`personnel_idpersonnel`) REFERENCES `personnel` (`idpersonnel`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
